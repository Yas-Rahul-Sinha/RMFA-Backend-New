obj = {"A":{"a":"a","b":"b"},"B":{"a":"c","b":"d"}}
for i in obj:
    print(i)